package com.example.cowdung;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.ItemInteractionResult;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.LevelReader;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;

public class CowDungBlock extends Block {
    public static final BooleanProperty LIT = BlockStateProperties.LIT;

    /** 点燃后多少 tick 爆炸（60 tick = 3 秒） */
    public static final int FUSE_TICKS = 60;
    /** 爆炸威力（苦力怕 3.0，TNT 4.0）。不会破坏方块，只伤害实体 */
    public static final float EXPLOSION_POWER = 1.5F;
    /** 中毒范围（格） */
    public static final double POISON_RADIUS = 4.0D;
    /** 中毒时长（tick），200 = 10 秒 */
    public static final int POISON_TICKS = 200;

    private static final VoxelShape SHAPE = Shapes.or(
            Block.box(3, 0, 3, 13, 3, 13),
            Block.box(5, 3, 5, 11, 5, 11));

    public CowDungBlock(Properties properties) {
        super(properties);
        registerDefaultState(stateDefinition.any().setValue(LIT, false));
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(LIT);
    }

    @Override
    protected VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
        return SHAPE;
    }

    @Override
    protected boolean canSurvive(BlockState state, LevelReader level, BlockPos pos) {
        BlockPos below = pos.below();
        return level.getBlockState(below).isFaceSturdy(level, below, Direction.UP);
    }

    @Override
    protected BlockState updateShape(BlockState state, Direction direction, BlockState neighborState,
                                     LevelAccessor level, BlockPos pos, BlockPos neighborPos) {
        if (direction == Direction.DOWN && !state.canSurvive(level, pos)) {
            return Blocks.AIR.defaultBlockState();
        }
        return super.updateShape(state, direction, neighborState, level, pos, neighborPos);
    }

    /** 拿打火石右键：点燃 */
    @Override
    protected ItemInteractionResult useItemOn(ItemStack stack, BlockState state, Level level, BlockPos pos,
                                              Player player, InteractionHand hand, BlockHitResult hit) {
        if (!stack.is(Items.FLINT_AND_STEEL)) {
            return super.useItemOn(stack, state, level, pos, player, hand, hit);
        }

        if (!state.getValue(LIT)) {
            level.playSound(player, pos, SoundEvents.FLINTANDSTEEL_USE, SoundSource.BLOCKS,
                    1.0F, level.getRandom().nextFloat() * 0.4F + 0.8F);
            if (!level.isClientSide()) {
                level.setBlock(pos, state.setValue(LIT, true), Block.UPDATE_ALL);
                level.scheduleTick(pos, this, FUSE_TICKS);
                level.playSound(null, pos, SoundEvents.TNT_PRIMED, SoundSource.BLOCKS, 1.0F, 1.0F);
                stack.hurtAndBreak(1, player, LivingEntity.getSlotForHand(hand));
            }
        }
        // 已点燃时也吃掉这次点击，避免在旁边点出火来
        return ItemInteractionResult.sidedSuccess(level.isClientSide());
    }

    /** 三秒引信到了：爆炸 + 中毒 */
    @Override
    protected void tick(BlockState state, ServerLevel level, BlockPos pos, RandomSource random) {
        if (state.getValue(LIT)) {
            explode(level, pos);
        }
    }

    private static void explode(ServerLevel level, BlockPos pos) {
        double x = pos.getX() + 0.5D;
        double y = pos.getY() + 0.25D;
        double z = pos.getZ() + 0.5D;

        level.removeBlock(pos, false);
        // NONE：不破坏方块，但会伤害并击退范围内的实体
        level.explode(null, x, y, z, EXPLOSION_POWER, Level.ExplosionInteraction.NONE);

        AABB area = new AABB(pos).inflate(POISON_RADIUS);
        for (Player player : level.getEntitiesOfClass(Player.class, area)) {
            if (!player.isSpectator() && player.distanceToSqr(x, y, z) <= POISON_RADIUS * POISON_RADIUS) {
                player.addEffect(new MobEffectInstance(MobEffects.POISON, POISON_TICKS, 0));
            }
        }
    }

    /** 点燃后冒烟冒火星（客户端） */
    @Override
    public void animateTick(BlockState state, Level level, BlockPos pos, RandomSource random) {
        if (state.getValue(LIT)) {
            double x = pos.getX() + 0.5D;
            double y = pos.getY() + 0.4D;
            double z = pos.getZ() + 0.5D;
            level.addParticle(ParticleTypes.SMOKE, x, y, z, 0.0D, 0.03D, 0.0D);
            level.addParticle(ParticleTypes.FLAME,
                    x + (random.nextDouble() - 0.5D) * 0.3D, y, z + (random.nextDouble() - 0.5D) * 0.3D,
                    0.0D, 0.0D, 0.0D);
        }
    }
}
