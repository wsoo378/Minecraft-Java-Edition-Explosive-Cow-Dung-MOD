package com.example.cowdung;

import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.entity.animal.Cow;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraftforge.event.entity.living.LivingEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = CowDungMod.MODID)
public class CowDungHandler {
    /** 拉屎间隔：2 分钟 = 2400 tick（测试时可以先改小，比如 100） */
    private static final long INTERVAL_TICKS = 2 * 60 * 20L;
    private static final String NEXT_DUNG_KEY = "CowDungNextTime";

    @SubscribeEvent
    public static void onLivingTick(LivingEvent.LivingTickEvent event) {
        // 蘑菇牛也是 Cow 的子类；只想要普通牛的话改成 event.getEntity().getType() == EntityType.COW
        if (!(event.getEntity() instanceof Cow cow)) {
            return;
        }
        Level level = cow.level();
        if (level.isClientSide() || !cow.isAlive() || cow.isBaby()) {
            return;
        }

        long now = level.getGameTime();
        CompoundTag data = cow.getPersistentData();
        if (!data.contains(NEXT_DUNG_KEY)) {
            data.putLong(NEXT_DUNG_KEY, now + INTERVAL_TICKS);
            return;
        }
        if (now >= data.getLong(NEXT_DUNG_KEY)) {
            data.putLong(NEXT_DUNG_KEY, now + INTERVAL_TICKS);
            dropDung(level, cow);
        }
    }

    private static void dropDung(Level level, Cow cow) {
        BlockPos pos = cow.blockPosition();
        BlockState dung = CowDungMod.COW_DUNG.get().defaultBlockState();
        BlockState current = level.getBlockState(pos);

        if (current.canBeReplaced() && level.getFluidState(pos).isEmpty() && dung.canSurvive(level, pos)) {
            level.setBlockAndUpdate(pos, dung);
        } else {
            // 放不下（比如站在台阶上、水里）就直接掉成物品
            cow.spawnAtLocation(CowDungMod.COW_DUNG_ITEM.get());
        }
        cow.playSound(SoundEvents.MUD_PLACE, 1.0F, 1.0F);
    }
}
