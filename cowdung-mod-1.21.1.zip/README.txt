Explosive Cow Dung —— Minecraft Java 1.21.1 / Forge 52.x

用法：
1. 从 files.minecraftforge.net 下载 1.21.1 的 MDK，解压（需要 JDK 21）。
2. 编辑 MDK 里的 gradle.properties：mod_id=cowdung，mod_name=Explosive Cow Dung，其余按需改。
3. 删掉 MDK 里 src/main/java 下自带的示例类（ExampleMod.java、Config.java）。
4. 把本压缩包的 src 文件夹合并进 MDK 的 src。
5. 运行  ./gradlew runClient  测试，  ./gradlew build  打包（jar 在 build/libs）。

测试：
  /give @p cowdung:cow_dung
  /summon cow
  把 CowDungHandler 里的 INTERVAL_TICKS 临时改成 100 可以快速看到拉屎。
